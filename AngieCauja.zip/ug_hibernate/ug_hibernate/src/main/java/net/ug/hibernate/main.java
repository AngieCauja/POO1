package net.ug.hibernate;

public class main {
	
	
	public static void main(String[] args) {
		crear();
		read();
		update();
		delete();
	}
	
	public static void crear() {
		DaoMesa daoMesa = new DaoMesa();
		Mesa mesa = new Mesa(1, 6, "centro", 8);
		daoMesa.setup();
		daoMesa.crear(mesa);
		Mesa mesa1 = new Mesa(2,7,"lateral",5);		
		daoMesa.crear(mesa);		
	}
	
	public static void read() {
		DaoMesa daoMesa = new DaoMesa();
		daoMesa.setup();
		Mesa mesa = daoMesa.read(1);
		mesa.imprimir();
	}

	public static void update() {

		DaoMesa daoMesa= new DaoMesa();
		daoMesa.setup();
		Mesa mesa = daoMesa.read(1);
		mesa.getCapacidad(4);
		daoMesa.update(mesa);
	}
	
	public static void delete() {
		DaoMesa daoMesa = new DaoMesa();
		daoMesa.setup();
		daoMesa.delete(1);
		daoMesa.delete(2);
	}
}
