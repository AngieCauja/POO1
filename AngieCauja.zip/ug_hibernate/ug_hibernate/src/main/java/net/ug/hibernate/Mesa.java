package net.ug.hibernate;

import javax.persistence.*;

@Entity
@Table(name = "mesa")
public class Mesa {
	@Id
	@Column(name = "mesa_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
	
	@Column(name = "Tipo")
    private int Capacidad;
    private String Ubicacion;
    private float Precio;
    
    
	public Mesa(long id, int capacidad, String ubicacion, float precio) {
		super();
		this.id = id;
		Capacidad = capacidad;
		Ubicacion = ubicacion;
		Precio = precio;
	}


	

	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public int getCapacidad() {
		return Capacidad;
	}


	public void setCapacidad(int capacidad) {
		Capacidad = capacidad;
	}


	public String getUbicacion() {
		return Ubicacion;
	}


	public void setUbicacion(String ubicacion) {
		Ubicacion = ubicacion;
	}


	public float getPrecio() {
		return Precio;
	}


	public void setPrecio(float precio) {
		Precio = precio;
	}


	
	
    
    
}
